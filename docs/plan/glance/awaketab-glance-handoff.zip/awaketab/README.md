# AwakeTab — Glance v3.1 (the one and only design)

This package contains **only the current design**. All earlier explorations were removed, so nothing can be built from a stale screen. Two full QA rounds were run on it (4 devices × light / dark / OLED × 5 languages, every panel, state and website page). Domain: **awaketab.com**.

| Path | What it is |
|---|---|
| `AGENT_PROMPT.md` | **Start here.** The complete build brief: stack, tokens, fonts, every screen, journey, vibes, extension, marketing, bugs to fix, work order and definition of done. |
| `assets/marketing/` | **Every launch asset at its exact pixel size:** OG / X share images (og-01…08), Chrome Web Store kit (icon 128, 5 screenshots 1280 × 800, 440 × 280 tile, 1400 × 560 marquee, Edge 300 logo), Product Hunt kit (240 thumbnail, 5 gallery 1270 × 760), launch post and story, and every favicon, extension and web-app icon. |
| `assets/marketing/LISTING_COPY.md` | The exact store text: name, summary, description, permission justifications, privacy answers, Product Hunt tagline, description and maker comment, meta tags, `<head>` snippet and extension `manifest.json`. |
| `html/index.html` | Static snapshots of every board. Open in a browser. |
| `prototype/` | The live design files (`Tool`, `Site`, `Page`, `Face`, `Scene` and boards G00–G15). Serve the folder over HTTP (`cd prototype && python3 -m http.server 8000`), then open a `.dc.html` file. Exact values live here. |
| `docs/tokens.css` | Colour, type, radius and motion tokens for light, dark and OLED, plus the logo geometry. |
| `../awaketab-glance-app.html` | One-file clickable tool. Open it directly. |

**Boards:**
- G00 foundation and rules
- G01 desktop tool · G02 tablet tool · G03 phone tool
- G04 home page
- Every website page: G05 (1440), G06 (834) and G08 (390) in light; G07 (1194) and G08b (390) in dark
- G09 every state, banner and panel (including OLED)
- G10 languages
- G11 all 46 faces, dark and light
- G12 extension, mini clock, widgets and wall mode
- G13 brand kit and the new mark
- G14 accessibility and keyboard
- G15 marketing, store and launch assets

**The mark:** a progress ring. The arc is the time left, the faint track is the time used, and the volt bead is *now*.

**No email anywhere:** sign-in is Apple / Google / passkey, and support is in-app feedback.

**Fonts:** Bricolage Grotesque (display) · Inter (UI, digits) · Instrument Serif Italic (one accent word) · Geist Mono (labels).
